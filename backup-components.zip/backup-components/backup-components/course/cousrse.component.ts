import { Component } from "@angular/core";

 // internal files = template , style

@Component({
  selector: 'app-courses',
  templateUrl: './course.component.html',
  styleUrls: ['course.component.css']
})
export class CourseComp {

}
