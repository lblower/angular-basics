import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-advance-course',
  templateUrl: './advance-course.component.html',
  styleUrls: ['./advance-course.component.css']
})
export class AdvanceCourseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
