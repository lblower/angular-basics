import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-simple-course',
  templateUrl: './simple-course.component.html',
  styleUrls: ['./simple-course.component.css']
})
export class SimpleCourseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
