import { Component } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent  {

// no logic / method in ts file as of now (can have input property)
// dumb component or presentation component
// other way - logical component - a compoenent with some logics that affect ur UI

}
